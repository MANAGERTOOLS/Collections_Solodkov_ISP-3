﻿double v1, v2, s, t, result;

Console.Write("V1 = ");
v1 = Convert.ToDouble(Console.ReadLine());
Console.Write("V2 = ");
v2 = Convert.ToDouble(Console.ReadLine());
Console.Write("S = ");
s = Convert.ToDouble(Console.ReadLine());
Console.Write("T = ");
t = Convert.ToDouble(Console.ReadLine());

result = s + v1 * t + v2 * t;
Console.Write(result);