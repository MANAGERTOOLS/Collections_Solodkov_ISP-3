﻿int n = Convert.ToInt32(Console.ReadLine()), sum = 0;
double r;

for (int i = 1; i <= n; i++)
{
    Console.Write("Введите число ");
    r = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine((int)(r + (r >= 0 ? 0.5 : -0.5)));

    sum += (int)(r + (r >= 0 ? 0.5 : -0.5));
}

Console.WriteLine("Сумма = " + sum);