﻿int a = Convert.ToInt32(Console.ReadLine()), b = Convert.ToInt32(Console.ReadLine());

if (a > b)
    Console.WriteLine($"Максимальное значение B = {Math.Min(a, b)}");
else
    Console.WriteLine($"Максимальное значение A = {Math.Min(a, b)}");