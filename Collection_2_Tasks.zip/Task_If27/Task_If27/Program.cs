﻿int x = Convert.ToInt32(Console.ReadLine()), f;

if (x < 0)
    f = 0;
else
if ((x % 2) == 0)
    f = 1;
else
    f = -1;
Console.WriteLine("F = " + f);