﻿int A = Convert.ToInt32(Console.ReadLine()), B = Convert.ToInt32(Console.ReadLine()), C = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"Длина отрезка AC = {C - A}, Длина отрезка BC = {C - B}");
Console.WriteLine($"Сумма отрезка AC = {A + C}, Сумма отрезка BC = {B + C}");