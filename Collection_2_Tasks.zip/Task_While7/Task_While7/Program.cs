﻿double a = Convert.ToDouble(Console.ReadLine()), pow = 1;

while (pow * pow <= a)
{
    pow++;
}

Console.WriteLine($"Наименьшее целое положительное число K, квадрат которого превосходит {a} равно {pow}");