﻿int a = Convert.ToInt32(Console.ReadLine()), b = Convert.ToInt32(Console.ReadLine()), c = Convert.ToInt32(Console.ReadLine());

if (b > a && b < c)
{
    Console.WriteLine("Верно");
}
else
{
    Console.WriteLine("Неверно");
}