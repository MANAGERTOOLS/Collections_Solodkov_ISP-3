﻿int x1 = Convert.ToInt32(Console.ReadLine()), x2 = Convert.ToInt32(Console.ReadLine()), y1 = Convert.ToInt32(Console.ReadLine()), y2 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));