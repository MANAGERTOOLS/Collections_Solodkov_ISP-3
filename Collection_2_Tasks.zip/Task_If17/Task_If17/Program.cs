﻿double a = Convert.ToDouble(Console.ReadLine()), b = Convert.ToDouble(Console.ReadLine()), c = Convert.ToDouble(Console.ReadLine());

if ((a < b && b > c))
{
    a = a * 2;
    b = b * 2;
    c = c * 2;
    Console.WriteLine($"Значение A = {a} {b} {c}");
}
else
{
    a = -a;
    b = -b;
    c = -c;
    Console.WriteLine($"Значение A = {a} {b} {c}");
}