﻿double a, b, c, sum, mul;
Console.Write("A = ");
a = Convert.ToDouble(Console.ReadLine());

b = a % 10;
c = a / 10;

sum = b + c;
mul = b * c;

Console.WriteLine($"Сумма равна {sum}");
Console.WriteLine($"Произведение равно {mul}");