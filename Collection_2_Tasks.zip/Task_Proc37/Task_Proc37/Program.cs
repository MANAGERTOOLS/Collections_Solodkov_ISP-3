﻿double Power1(double A, double B)
{
    return A <= 0 ? 0 : Math.Exp(B * Math.Log(A));
}