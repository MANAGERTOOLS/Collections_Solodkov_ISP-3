﻿int a = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"Периметр квадрата равен {4 * a}");