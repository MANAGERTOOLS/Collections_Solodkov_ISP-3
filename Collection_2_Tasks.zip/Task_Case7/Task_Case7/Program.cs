﻿int a = Convert.ToInt32(Console.ReadLine()), b = Convert.ToInt32(Console.ReadLine());

switch (a)
{
    case 1:
        Console.WriteLine("${1 * a} килограмм");
        break;
    case 2:
        Console.WriteLine("${1000000 * a} милиграмм");
        break;
    case 3:
        Console.WriteLine("${1000 * a} грамм");
        break;
    case 4:
        Console.WriteLine("${a / 1000} тонн");
        break;
    case 5:
        Console.WriteLine("${a / 100} центнер");
        break;
}