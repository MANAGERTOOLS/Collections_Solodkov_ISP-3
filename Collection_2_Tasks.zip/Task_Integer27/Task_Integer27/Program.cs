﻿int k, m;

Console.Write("K = ");
k = Convert.ToInt16(Console.ReadLine());

m = ((k + 4) % 7) + 1;

if (m == 1) { Console.WriteLine($"{m} - Monday"); }
else if (m == 2) { Console.WriteLine($"{m} - Tuesday"); }
else if (m == 3) { Console.WriteLine($"{m} - Wensday"); }
else if (m == 4) { Console.WriteLine($"{m} - Thursday"); }
else if (m == 5) { Console.WriteLine($"{m} - Friday"); }
else if (m == 6) { Console.WriteLine($"{m} - Saturday"); }
else if (m == 7) { Console.WriteLine($"{m} - Sunday"); }