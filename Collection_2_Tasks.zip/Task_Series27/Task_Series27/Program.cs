﻿int n = Convert.ToInt32(Console.ReadLine());
double a, pow = 1;

for (int i = 1; i <= n; i++)
{
    a = Convert.ToDouble(Console.ReadLine());
    Console.WriteLine(">");
    for (int j = 1; j <= i; j++)
    {
        pow *= a;
    }
    Console.WriteLine(pow);
}