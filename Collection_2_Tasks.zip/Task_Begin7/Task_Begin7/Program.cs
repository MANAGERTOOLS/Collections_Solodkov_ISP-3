﻿int R = Convert.ToInt32(Console.ReadLine());

Console.WriteLine($"L = + {2 * Math.PI * R}");
Console.WriteLine($"S = {Math.PI * Math.Pow(R, 2)}");