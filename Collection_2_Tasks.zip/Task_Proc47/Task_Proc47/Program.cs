﻿int NOD2(int A, int B)
{
    while ((A != 0) && (B != 0))
    {
        if (A > B)
        {
            A %= B;
        }
        else
        {
            B %= A;
        }
    }

    return A + B;
}

void Frac1(int a, int b, int p, int q)
{
    p = a / NOD2(a, b);
    q = b / NOD2(a, b);
}