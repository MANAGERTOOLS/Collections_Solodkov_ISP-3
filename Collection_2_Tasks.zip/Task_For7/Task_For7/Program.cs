﻿int a = Convert.ToInt32(Console.ReadLine()), b = Convert.ToInt32(Console.ReadLine()), sum = 0;

for (int i = a; i <= b; i++)
{
    sum += i;
}

Console.WriteLine($"Сумма чисел от {a} до {b} включительно равна {sum}");