﻿int a = Convert.ToInt32(Console.ReadLine());

if (a > 99 && a < 1000 && a % 2 != 0) Console.WriteLine(true);
else Console.WriteLine(false);