﻿int a = Convert.ToInt32(Console.ReadLine()), f = 0, f1 = 1, f2 = 1, k = 2;

while (f < a)
{
    k++;
    f = f2 + f1;
    f2 = f1;
    f1 = f;
}

Console.WriteLine(k);