﻿int x = Convert.ToInt32(Console.ReadLine()), x1 = Convert.ToInt32(Console.ReadLine()), y = Convert.ToInt32(Console.ReadLine()), y1 = Convert.ToInt32(Console.ReadLine());

if (Math.Abs(x - x1) <= 1 && Math.Abs(y - y1) <= 1) Console.WriteLine(true);
else Console.WriteLine(false);