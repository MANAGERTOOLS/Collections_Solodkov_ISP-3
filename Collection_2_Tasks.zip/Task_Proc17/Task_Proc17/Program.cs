﻿double RootsCount(int A, int B, int C)
{
    return Math.Pow(B, 2) - 4 * (A * C);
}