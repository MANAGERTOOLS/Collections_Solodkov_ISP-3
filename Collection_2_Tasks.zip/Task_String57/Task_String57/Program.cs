﻿string s = Console.ReadLine();

if (s.Contains("  "))
{
    s = " ";
}