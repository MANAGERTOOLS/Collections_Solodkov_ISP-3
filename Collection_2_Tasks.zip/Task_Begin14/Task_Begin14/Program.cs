﻿double L = Convert.ToDouble(Console.ReadLine()), R;

R = L / 2 * Math.PI;
Console.WriteLine($"R = {R}");
Console.WriteLine($"S = {Math.PI * Math.Pow(R, 2)}");