﻿int A = Convert.ToInt32(Console.ReadLine());
int temp;

temp = A * A;
Console.WriteLine($"{A}^2 = {temp}");

temp = temp * temp;
Console.WriteLine($"{A}^3 = {temp}");

temp = temp * temp;
Console.WriteLine($"{A}^4 = {temp}");