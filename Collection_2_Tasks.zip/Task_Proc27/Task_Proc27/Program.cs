﻿bool IsPowerN(int K, int N)
{
    double temp = K;
    for (double i = temp; temp >= N; temp++)
    {
        temp /= N;
    }

    return temp == 1;
}