﻿void InvertDigits(int K)
{
    int temp = K;
    K = 0;
    while(temp != 0)
    {
        K = K * 10 + (temp % 10);
        temp /= 10;
    }
}