﻿string s = Console.ReadLine();

Console.WriteLine(s.ToLower());