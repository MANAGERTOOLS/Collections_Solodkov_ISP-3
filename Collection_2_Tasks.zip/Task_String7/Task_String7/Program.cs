﻿string s = Console.ReadLine();

Console.WriteLine($"{s[1]} - {s[s.Length]}");