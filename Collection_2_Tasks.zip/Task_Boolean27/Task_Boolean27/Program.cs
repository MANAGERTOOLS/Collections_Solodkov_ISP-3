﻿int x = Convert.ToInt32(Console.ReadLine()), y = Convert.ToInt32(Console.ReadLine());

if ((x <= 0) || (x < 0 && y < 0)) Console.WriteLine(true);
else Console.WriteLine(false);