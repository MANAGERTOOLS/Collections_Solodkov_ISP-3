﻿double a = Convert.ToDouble(Console.ReadLine()), pow = 1, sum = 0;

for (int i = 1; i <= a; i++)
{
    for (int j = 1; j <= i; j++)
    {
        pow *= i;
    }

    sum += pow;
    pow = 1;
}

Console.WriteLine(sum);