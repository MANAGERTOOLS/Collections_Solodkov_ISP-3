﻿int a = Convert.ToInt32(Console.ReadLine()), n = Convert.ToInt32(Console.ReadLine()), result = a, pow = a, temp = 1, temp_1 = 1;

for (int i = 0; i < n; i++)
{
    temp = temp * (2 * i - 1);
    temp_1 = temp_1 * (2 * i);
    pow = pow * a * a;
    result = result + temp * pow / (temp_1 * (2 * i + 1));
}