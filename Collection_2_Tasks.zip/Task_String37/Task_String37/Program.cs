﻿string s = Console.ReadLine(), s1 = Console.ReadLine(), s2 = Console.ReadLine();

if (s.Contains(s1))
{
    s1 = s2;
}