﻿int a = Convert.ToInt32(Console.ReadLine()), sum = 0, temp = 1;
double n = Convert.ToDouble(Console.ReadLine());

for (int i = 2; i <= n; i++)
{
    temp *= a;
    sum += temp;
}

Console.WriteLine($"Сумма чисел равна {sum}");