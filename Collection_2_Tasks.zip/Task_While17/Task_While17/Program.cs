﻿int a = Convert.ToInt32(Console.ReadLine());

while (a > 0)
{
    Console.WriteLine(a % 10);
    a /= 10;
}