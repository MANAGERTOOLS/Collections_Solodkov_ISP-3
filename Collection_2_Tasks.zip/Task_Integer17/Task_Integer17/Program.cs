﻿int a, b;

Console.Write("A = ");
a = Convert.ToInt32(Console.ReadLine());

b = a % 1000 / 100;
Console.Write($"B = {b}");