﻿int n = Convert.ToInt32(Console.ReadLine());
int a = 9;
int b = 16;
int m = 8;

int sum = 0;
int mul = 1;

while (n > 0)
{
    sum += n;

    mul *= n;

    if (sum > a)
    {
        Console.WriteLine("Верно");
    }

    if (mul > b)
    {
        Console.WriteLine("Верно");
    }

    n /= 10;
}

if (n % 10 > m)
{
    Console.WriteLine("Верно");
}