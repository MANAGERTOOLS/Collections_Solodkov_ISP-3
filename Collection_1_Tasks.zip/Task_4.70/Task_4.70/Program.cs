﻿float a = 4.8f;
float b = 9.2f;
float max = 0;

if (a > b)
{
    max = a;
}
else
{
    max = b;
}

Console.WriteLine(max);

Console.WriteLine(Math.Max(a, b));