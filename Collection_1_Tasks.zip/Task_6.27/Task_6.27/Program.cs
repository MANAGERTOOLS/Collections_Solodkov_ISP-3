﻿int n = Convert.ToInt32(Console.ReadLine());
int max = 0;
int min = 0;

while (n > 0)
{
    if (max < n % 10)
    {
        max = n % 10;
    }

    if (min > n % 10)
    {
        min = n % 10;
    }

    n /= 10;
}

Console.WriteLine(max);
Console.WriteLine(min);
Console.WriteLine(max - min);
Console.WriteLine(max + min);