﻿double[] numbers = { 7.3, 9.1, 8.4, 7.2, 8.8 };

for (int i = 0; i < numbers.Length; i++)
{
    if (numbers[i] > 10)
    {
        numbers[i] = Math.Pow(numbers[i], 2);
    }

    if (i % 2 == 0)
    {
        numbers[i] = Math.Abs(numbers[i]);
    }
}