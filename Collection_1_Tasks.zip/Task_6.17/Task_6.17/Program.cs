﻿double a = Convert.ToDouble(Console.ReadLine());

int n = 10;

double result = 0;

for (int i = 1; i <= n; i++)
{
    result += 1 + (1 / n);

    if (result > a)
    {
        Console.WriteLine(result);
    }
}