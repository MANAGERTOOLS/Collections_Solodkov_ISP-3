﻿int[] numbers = { 8, 1, 5, 2, 5, 9 };
int mul = 1;

for (int i = 0; i < numbers.Length; i++)
{
    mul *= numbers[i];
}

Console.WriteLine(mul);