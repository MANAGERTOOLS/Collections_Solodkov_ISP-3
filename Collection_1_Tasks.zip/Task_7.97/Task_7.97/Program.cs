﻿int[] n = { 1, 3, 2, 5, 3 };
int sum = 0;
int sum_1 = 0;

for (int i = 0; i < n.Length; i++)
{
    if (n[i] <= 20)
    {
        sum += n[i];
    }

    if (n[i] <= 10)
    {
        sum_1 += n[i];
    }
}

if (sum <= 50)
{
    Console.WriteLine("Верно");
}

if (sum_1 % 3 == 0)
{
    Console.WriteLine("Верно");
}