﻿double[] peopleWeight = { 100.0, 73.3, 96.4, 56.2, 65.2 };
double sum = 0;

for (int i = 0; i < peopleWeight.Length; i++)
{
    sum += peopleWeight[i];
}

Console.WriteLine(sum / peopleWeight.Length);