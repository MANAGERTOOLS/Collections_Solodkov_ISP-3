﻿int count = 0;
double[] b = { 3.2, 9.1, 8.3, 0.3, 5.3, 6.3, 8.3, 4.5 };

for (int i = 0; i < b.Length; i++)
{
    if (b[i] < 100)
    {
        count += 1;
    }
}

Console.WriteLine(count);