﻿int Factorial(int n)
{
    if (n == 1)
    {
        return 1;
    }

    return n * Factorial(n - 1);
}

Console.WriteLine((2 * Factorial(5) + 3 * Factorial(8)) / Factorial(6) + Factorial(4));