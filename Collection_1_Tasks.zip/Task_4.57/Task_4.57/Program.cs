﻿int a = 731;
int n = 3;

if (a.ToString().Contains("6"))
{
    Console.WriteLine($"Число {a} содержит цифру 6");
}

if (a.ToString().Contains(n.ToString()))
{
    Console.WriteLine($"Число {a} содержит цифру {n}");
}