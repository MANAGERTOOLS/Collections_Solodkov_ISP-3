﻿int a = 5;
int b = 9;

if (Math.Pow(b, 2) < a)
{
    b *= 5;
}