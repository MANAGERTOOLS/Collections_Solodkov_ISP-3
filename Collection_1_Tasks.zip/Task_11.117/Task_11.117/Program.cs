﻿int[] candiesCost = { 193, 327, 831, 374, 187 };

int cheap = int.MaxValue;

int cheapIndex = 0;

for (int i = 0; i < candiesCost.Length; i++)
{
    if (cheap > candiesCost[i])
    {
        cheap = candiesCost[i];

        cheapIndex = i;
    }
}

Console.WriteLine(cheapIndex);