﻿double y = 0;
double t = 0;

for (double i = 4; i <= 28; i++)
{
    t = i + 2;
    y = 2 * (double)Math.Pow(t, 2) + 5.5f * t - 2;
    Console.WriteLine(y);
}