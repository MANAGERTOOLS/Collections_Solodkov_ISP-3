﻿int[] a = { 1, 5, 2, 3, 1, 8, 3, 5, 1, 9, 11, 26, 32, 67, 1, 6, 3, 8, 9, 21 };

for (int i = 1; i < 20; i++)
{
    if ((a[i - 1] * a[i]) % 2 != 0)
    {
        break;
    }

    if (i == 20)
    {
        Console.WriteLine("Соседних нечётных чисел нет!");
    }

    else
    {
        Console.WriteLine(i - 1 + " ");
    }
}