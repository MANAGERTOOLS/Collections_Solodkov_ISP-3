﻿int[] marks = { 5, 3, 4, 2 };
int[] marks_1 = { 2, 3, 5, 4 };

int sum = 0;

for (int i = 0; i < 4; i++)
{
    sum += marks[i] + marks_1[i];
}

Console.WriteLine(sum);