﻿int a = 4;
int b = 2;

int x = a % b;
int y = b % a;

Console.WriteLine(x * y + 1);

Console.ReadKey();