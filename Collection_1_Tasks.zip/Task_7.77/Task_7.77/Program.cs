﻿int A = Convert.ToInt32(Console.ReadLine());
int[] numbers = { 8, 8, 8, 8, A };
int count = 0;

for (int i = 0; i < numbers.Length; i++)
{
    if (numbers[i] == 8)
    {
        count += 1;
    }
}

Console.WriteLine(count);