﻿float a = 5.10f;
float b = 10.5f;

Console.WriteLine("Максимальное число: " + Math.Max(a, b) + " " + "Минимальное число: " + Math.Min(a, b));
Console.ReadKey();