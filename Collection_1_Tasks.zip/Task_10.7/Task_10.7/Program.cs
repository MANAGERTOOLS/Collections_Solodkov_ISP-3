﻿int[] ABC = { 6, 2, 8 };
int[] CBA = { 8, 1, 3 };

int Perimeter(int[] ABC)
{
    int sum = 0;

    for (int i = 0; i < ABC.Length; i++)
    {
        sum += ABC[i];
    }

    return sum;
}

Console.WriteLine(Perimeter(ABC) + Perimeter(CBA));