﻿int n = 10;

int sum = 0;

for (int i = 1; i <= n; i++)
{
    sum += i * i;
}

Console.WriteLine(sum);