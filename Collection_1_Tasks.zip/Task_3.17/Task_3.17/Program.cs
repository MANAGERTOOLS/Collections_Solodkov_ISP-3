﻿bool trueA = true;
bool falseA = false;
bool trueB = true;
bool falseB = false;

bool a = !trueA & !trueB || trueA;
bool b = trueB || !trueA && !trueB;
bool c = trueB & !(trueA & !trueB);

bool a1 = !falseA & !falseB || falseA;
bool b1 = falseB || !falseA && !falseB;
bool c1 = falseB & !(falseA & !falseB);

Console.WriteLine("Значение логического выражения при A и B - True");
Console.WriteLine(a);
Console.WriteLine(b);
Console.WriteLine(c);

Console.WriteLine("Значение логического выражения при A и B - False");
Console.WriteLine(a1);
Console.WriteLine(b1);
Console.WriteLine(c1);

Console.ReadKey();