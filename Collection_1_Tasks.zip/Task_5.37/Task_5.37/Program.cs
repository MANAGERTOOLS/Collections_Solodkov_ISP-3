﻿int x = 2;

for (int i = 1; i <= 10; i++)
{
    Console.WriteLine(i - (i / 3 * x) + (i / 4 * Math.Pow(x, 2)) - (i / 5 * Math.Pow(x, 3)));
}