﻿double R = 6350000;
double h = 900;

double S = Math.Pow((Math.Pow((R + h), 2) - Math.Pow(R, 2)), 0.5);
Console.WriteLine("S = " + S);
Console.ReadKey();