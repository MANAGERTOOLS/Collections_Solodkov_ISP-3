﻿int a = Convert.ToInt32(Console.ReadLine());

if (-5 >= a && a <= 3)
{
    Console.WriteLine("Число принадлежит интервалу -5, 3");
}