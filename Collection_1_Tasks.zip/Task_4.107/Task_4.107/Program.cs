﻿int n = Convert.ToInt32(Console.ReadLine());
bool v = true;

switch (n)
{
    case 2:
        if (!v)
            Console.WriteLine("в месяце 28 дней");
        else
            Console.WriteLine("в месяце 29 дней");
        break;
    case 4:
        Console.WriteLine("в месяце 30 дней");
        break;
    case 6:
        Console.WriteLine("в месяце 30 дней");
        break;
    case 9:
        Console.WriteLine("в месяце 30 дней");
        break;
    case 11:
        Console.WriteLine("в месяце 30 дней");
        break;
    default:
        Console.WriteLine("в месяце 31 дней");
        break;

}