﻿int n = Convert.ToInt32(Console.ReadLine());
int i = n % 10;

if (10 < n && n < 20)
{
    Console.WriteLine($"Ему {n} лет");
}
else if (1 < i && i < 5)
{
    Console.WriteLine($"Ему {n} года");
}
else if (i == 1)
{
    Console.WriteLine($"Ему {n} год");
}
else
{
    Console.WriteLine($"Ему {n} лет");
}