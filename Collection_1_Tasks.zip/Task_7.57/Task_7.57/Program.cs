﻿double max = 0;
double[] carsSpeed = { 100.3, 110.2, 183.9, 192.4, 103.67, 183.3 };

for (int i = 0; i < carsSpeed.Length; i++)
{
    if (max < carsSpeed[i])
    {
        max = carsSpeed[i];
    }
}

Console.WriteLine(max);