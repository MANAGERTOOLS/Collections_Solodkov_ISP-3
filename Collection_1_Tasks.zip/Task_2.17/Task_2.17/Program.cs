﻿int n = 537;

int x = n / 100;
int y = n / 10 % 10;
int z = n % 10;

Console.WriteLine(x.ToString() + z.ToString() + y.ToString());

Console.ReadKey();