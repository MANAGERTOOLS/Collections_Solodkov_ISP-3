﻿int x = 50;
int y = 25;

Console.WriteLine(x > 2 && y > 3);
Console.WriteLine(x > 1 || y > -2);
Console.WriteLine(x >= 0 && y < 5);
Console.WriteLine(x > 3 || x < -1);
Console.WriteLine(x > 3 && x < 10);
Console.WriteLine(x < 2);
Console.WriteLine(x < 0 && x < 5);
Console.WriteLine(10 < x && x <= 20);
Console.WriteLine(0 < y && y <= 4 && x < 5);