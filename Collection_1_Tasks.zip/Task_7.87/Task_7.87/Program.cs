﻿int p = Convert.ToInt32(Console.ReadLine());
int[] n = { 1, 3, 2, 5, 3 };
int sum = 0;

for (int i = 0; i < n.Length; i++)
{
    sum += n[i];
}

if (sum < p)
{
    Console.WriteLine("Верно");
}
else
{
    Console.WriteLine("Неверно");
}