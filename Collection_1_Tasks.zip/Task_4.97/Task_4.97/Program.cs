﻿int a = 3;
int b = 9;
int c = 4;
int max = Math.Max(a, b);
int min = Math.Min(a, b);

if (c > max)
{
    max = c;
}

if (c < min)
{
    min = c;
}

if (c > min && c < max)
{
    Console.WriteLine($"Число {c} является средним числом");
}