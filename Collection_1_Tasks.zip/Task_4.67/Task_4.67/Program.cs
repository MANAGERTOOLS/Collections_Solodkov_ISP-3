﻿int k = 6;
int d = k % 7;

if (d == 0 || d == 6)
{
    Console.WriteLine("Выходной день");
}
else
{
    Console.WriteLine("Рабочий день");
}