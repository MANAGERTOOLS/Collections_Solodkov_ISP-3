﻿int[] numbers = { 8, 1, 4, 2, 5 };

int max = int.MinValue;
int min = int.MaxValue;

int maxIndex = 0;
int minIndex = 0;

for (int i = 0; i < numbers.Length; i++)
{
    if (numbers[i] > max)
    {
        max = numbers[i];

        maxIndex = i;
    }

    if (min > numbers[i])
    {
        min = numbers[i];

        minIndex = i;
    }
}

Console.WriteLine(max);
Console.WriteLine(min);
Console.WriteLine(max - min);
Console.WriteLine(maxIndex);
Console.WriteLine(minIndex);
Console.ReadKey();