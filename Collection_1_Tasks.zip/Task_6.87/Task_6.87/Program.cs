﻿int points = 0;
int points_1 = 0;

Random random = new Random();

for (int i = 1; i <= 3; i++)
{
    points += random.Next(1, 3);
    Console.WriteLine($"Первая команда: {points} очков");
}

for (int i = 1; i <= 3; i++)
{
    points_1 += random.Next(1, 3);
    Console.WriteLine($"Вторая команда: {points_1} очков");
}

if (points > points_1)
{
    Console.WriteLine($"Выиграла первая команда - {points} очков");
}
else
{
    Console.WriteLine($"Выиграла вторая команда - {points_1} очков");
}