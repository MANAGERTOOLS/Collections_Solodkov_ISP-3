﻿int a = Convert.ToInt32(Console.ReadLine());
int b = Convert.ToInt32(Console.ReadLine());

int sum = 0;
int sum_1 = 0;
int sum_2 = 0;
int sum_3 = 0;

for (int i = 100; i < 500; i++)
{
    sum += i;
}

for (int i = a; i < 500; i++)
{
    sum_1 += i;
}

for (int i = -10; i > b; i--)
{
    sum_2 += i;
}

for (int i = a; i > b; i++)
{
    sum_3 += i;
}