﻿int f;
int x = 3;

if (x <= 0)
{
    f = 0;
}
else if (0 <= x && x <= 1)
{
    f = x;
}
else
{
    f = x * x;
}