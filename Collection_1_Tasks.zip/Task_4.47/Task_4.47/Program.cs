﻿int a = 5;
int b = 3;
int c = 12;

if (a == b)
{
    Console.WriteLine("Треугольник со сторонами a, b, c является равнобедренным");
}