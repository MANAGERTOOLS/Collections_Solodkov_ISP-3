﻿int a = 4;
int b = 2;

if (b % 2 == 0)
{
    Console.WriteLine("b является делителем числа a");
}
else if (a % 2 == 0)
{
    Console.WriteLine("a является делителем числа b");
}