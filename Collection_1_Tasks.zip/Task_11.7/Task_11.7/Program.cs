﻿int[] numbers = new int[20];
int n = 1;

for(int i = 0; i < numbers.Length; i++)
{
    n += 1;
    numbers[i] += n;
}

for(int i = numbers.Length - 1; i >= 0; i--)
{
    Console.WriteLine(numbers[i]);
}