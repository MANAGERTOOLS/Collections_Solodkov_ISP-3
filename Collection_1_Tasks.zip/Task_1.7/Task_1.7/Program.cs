﻿int[] numbers = { 5, 1, 9 };
foreach (var c in numbers)
{
    Console.Write(c + "  ");
}
Console.ReadKey();