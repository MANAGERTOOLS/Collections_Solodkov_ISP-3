﻿bool A = true;
bool B = false;
bool C = false;

bool a = A || !(A & B) || C;
bool b = !A || A & (B || C);
bool c = (A || B & !C) & C;

Console.WriteLine(a);
Console.WriteLine(b);
Console.WriteLine(c);

Console.ReadKey();