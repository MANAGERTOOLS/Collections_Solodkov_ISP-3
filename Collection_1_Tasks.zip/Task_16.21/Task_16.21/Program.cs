﻿Random rnd = new Random();
int[] array = new int[100];

Console.WriteLine("Массив со случайными числами: ");

for (int i = 0; i < 100; i++)
{
    array[i] = rnd.Next(0, 101);

    if (i != 99)
        Console.Write("{0}, ", array[i]);

    else
        Console.WriteLine("{0}.", array[i]);
}

Console.Write("Элементы в массиве равные 0 и 1: ");

foreach (int a in array)
{
    if (a == 0 || a == 1)
        Console.Write(a + " ");
}

Console.ReadKey();