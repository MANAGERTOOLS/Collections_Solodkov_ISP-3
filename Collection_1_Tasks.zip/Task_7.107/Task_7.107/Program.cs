﻿int x = Convert.ToInt32(Console.ReadLine());
int[] n = { -1, 3, -2, 5, -3 };
int count = 0;

for (int i = 0; i < n.Length; i++)
{
    if (n[i] < 0)
    {
        count += 1;
    }
}

if (count < x)
{
    Console.WriteLine("Верно");
}