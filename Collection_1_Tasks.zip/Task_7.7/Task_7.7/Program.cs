﻿int count = 0;

int Sum(int n)
{
    int sum = 0;

    while (n > 0)
    {
        sum += n;

        n /= 10;
    }

    return sum;
}

for (int i = 100; i < 500; i++)
{
    if (Sum(i) > 15)
    {
        count += 1;
    }
}

Console.WriteLine(count);