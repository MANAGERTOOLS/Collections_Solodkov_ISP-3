﻿double[] boyHeight = { 1.34, 1.65, 1.93, 1.83, 2.4 };
double[] girlHeight = { 1.23, 1.42, 2.3, 1.99, 1.13 };
double averageBoy = 0;
double averageGirl = 0;

for (int i = 0; i < 5; i++)
{
    averageBoy += boyHeight[i];
    averageGirl += girlHeight[i];
}

Console.WriteLine("Средний рост мальчиков равен" + averageBoy / 5);
Console.WriteLine("Средний рост девочек равен" + averageGirl / 5);